package cn.itcast.mp.service;

import cn.itcast.mp.pojo.User;
import com.baomidou.mybatisplus.extension.service.IService;

public interface UserService extends IService<User> {
}
